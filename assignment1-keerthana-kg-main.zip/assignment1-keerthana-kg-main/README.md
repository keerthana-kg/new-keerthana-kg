[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Gyq4IJC4)

# README.md

## Question 1 - Solution 1: String Operations
Write a Python program to perform various string operations.

**Functions:**
- `reverse_string(s)`
- `is_palindrome(s)`
- `count_vowels(s)`
- `to_uppercase(s)`
- `to_lowercase(s)`
- `capitalize_string(s)`
- `replace_substring(s, old, new)`
- `find_substring(s, sub)`
- `split_string(s, delimiter=" ")`
- `join_strings(strings, delimiter=" ")`

**Sample Input:**
```python
# Input for various functions
s = "Hello World"
```

**Sample Output:**
```python
# Outputs
reverse_string(s) -> "dlroW olleH"
is_palindrome("Racecar") -> True
count_vowels(s) -> 3
to_uppercase(s) -> "HELLO WORLD"
to_lowercase(s) -> "hello world"
capitalize_string(s) -> "Hello world"
replace_substring(s, "World", "Universe") -> "Hello Universe"
find_substring(s, "World") -> 6
split_string(s) -> ["Hello", "World"]
join_strings(["Hello", "World"]) -> "Hello World"
```

---

## Question 2 - Solution 2: Arithmetic Operations
Write a Python program to perform basic arithmetic operations.

**Functions:**
- `add(a, b)`
- `subtract(a, b)`
- `multiply(a, b)`
- `divide(a, b)`
- `power(a, b)`
- `floor_division(a, b)`
- `modulus(a, b)`
- `is_greater(a, b)`
- `is_equal(a, b)`
- `is_lesser(a, b)`

**Sample Input:**
```python
# Input
a = 10
b = 3
```

**Sample Output:**
```python
# Outputs
add(a, b) -> 13
subtract(a, b) -> 7
multiply(a, b) -> 30
divide(a, b) -> 3.3333333333333335
power(a, b) -> 1000
floor_division(a, b) -> 3
modulus(a, b) -> 1
is_greater(a, b) -> True
is_equal(a, b) -> False
is_lesser(a, b) -> False
```

---

## Question 3 - Solution 3: List Operations
Write a Python program to perform various list operations.

**Functions:**
- `find_max(lst)`
- `find_min(lst)`
- `list_sum(lst)`
- `average(lst)`
- `sort_list(lst)`
- `reverse_list(lst)`
- `append_element(lst, element)`
- `remove_element(lst, element)`
- `count_occurrences(lst, element)`
- `find_index(lst, element)`

**Sample Input:**
```python
# Input
lst = [5, 3, 8, 6]
element = 3
```

**Sample Output:**
```python
# Outputs
find_max(lst) -> 8
find_min(lst) -> 3
list_sum(lst) -> 22
average(lst) -> 5.5
sort_list(lst) -> [3, 5, 6, 8]
reverse_list(lst) -> [6, 8, 3, 5]
append_element(lst, 10) -> [5, 3, 8, 6, 10]
remove_element(lst, 3) -> [5, 8, 6]
count_occurrences(lst, 8) -> 1
find_index(lst, 6) -> 3
```

---

## Question 4 - Solution 4: Set Operations
Write a Python program to perform set operations.

**Functions:**
- `union_sets(set1, set2)`
- `intersection_sets(set1, set2)`
- `difference_sets(set1, set2)`
- `symmetric_difference(set1, set2)`
- `is_subset(set1, set2)`
- `is_superset(set1, set2)`
- `add_element(set1, element)`
- `remove_element(set1, element)`
- `is_disjoint(set1, set2)`
- `clear_set(set1)`

**Sample Input:**
```python
# Input
set1 = {1, 2, 3}
set2 = {3, 4, 5}
element = 4
```

**Sample Output:**
```python
# Outputs
union_sets(set1, set2) -> {1, 2, 3, 4, 5}
intersection_sets(set1, set2) -> {3}
difference_sets(set1, set2) -> {1, 2}
symmetric_difference(set1, set2) -> {1, 2, 4, 5}
is_subset(set1, set2) -> False
is_superset(set1, set2) -> False
add_element(set1, element) -> {1, 2, 3, 4}
remove_element(set1, 3) -> {1, 2, 4}
is_disjoint(set1, set2) -> False
clear_set(set1) -> set()
```

---

## Question 5 - Solution 5: Simplified Arithmetic Operations
Write a Python program to perform basic arithmetic operations for educational purposes.

**Functions:**
- `add(a, b)`
- `subtract(a, b)`
- `multiply(a, b)`
- `divide(a, b)`

**Sample Input:**
```python
# Input
a = 15
b = 5
```

**Sample Output:**
```python
# Outputs
add(a, b) -> 20
subtract(a, b) -> 10
multiply(a, b) -> 75
divide(a, b) -> 3.0
```

--- 

Save the program as `solution.py` and verify the outputs against the provided inputs to ensure correctness.
